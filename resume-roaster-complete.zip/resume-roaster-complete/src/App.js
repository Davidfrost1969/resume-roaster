import React from 'react';
import ResumeRoaster from './ResumeRoaster';

function App() {
  return (
    <div className="App">
      <ResumeRoaster />
    </div>
  );
}

export default App;
